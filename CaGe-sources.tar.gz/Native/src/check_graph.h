
extern int check_graph (void *graph, int dimension, char *function_name);
/*
   An auxiliary function for functions that output graphs.
   Returns 0 if nGraph is non-NULL and has the coordinates required
   by the "dimension" parameter.
*/

