package cage.viewer.twoview;

import java.io.File;

/**
 *
 * @author nvcleemp
 */
public interface TwoViewSaver {
    void saveFile(File file);
}
