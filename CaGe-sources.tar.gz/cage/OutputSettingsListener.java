package cage;

/**
 *
 * @author nvcleemp
 */
public interface OutputSettingsListener {
    void generatorInfoChanged(GeneratorInfo generatorInfo);    
}
