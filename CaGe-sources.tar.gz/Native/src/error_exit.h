
extern void error_exit (char *msg, char *error_class);
/*
   Prints error messages and exits.
   Some versions require an extern char * named "cmd_name".
*/

