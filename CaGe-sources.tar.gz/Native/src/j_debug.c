
int debug_native_pipe = 0;
int debug_native_graph = 0, debug_native_embedder = 0;
int debug_read_graphs = 0, debug_pipe = 0;
int debug_dstring = 0, debug_malloc = 0;

