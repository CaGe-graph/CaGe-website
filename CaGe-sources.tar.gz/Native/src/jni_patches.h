
# ifndef JNI_PATCHES_INCLUDED
# define JNI_PATCHES_INCLUDED


# if defined(__GNUC__) && defined(_WIN32)
typedef long long __int64;
# endif

# endif

