package cage.viewer.twoview;

/**
 *
 */
public class FloatingPoint {

    public double x, y;
}
